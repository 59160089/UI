<?php $pid=rand(1,100000000); echo $pid; ?>
